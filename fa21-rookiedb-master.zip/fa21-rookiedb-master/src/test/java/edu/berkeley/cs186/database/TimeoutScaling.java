package edu.berkeley.cs186.database;

public final class TimeoutScaling {
    // How much to scale test timeouts by.
    public static final double factor = 1.0;
}
