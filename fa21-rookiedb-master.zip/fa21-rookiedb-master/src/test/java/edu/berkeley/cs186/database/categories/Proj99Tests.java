package edu.berkeley.cs186.database.categories;

public interface Proj99Tests extends ProjTests { /* category marker for non-project tests */ }