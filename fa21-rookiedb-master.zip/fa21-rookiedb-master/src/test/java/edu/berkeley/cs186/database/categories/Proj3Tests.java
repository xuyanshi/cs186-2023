package edu.berkeley.cs186.database.categories;

public interface Proj3Tests extends ProjTests  { /* category marker */ }