package edu.berkeley.cs186.database.categories;

public interface SystemTests { /* category marker */ }
