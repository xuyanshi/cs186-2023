package edu.berkeley.cs186.database.categories;

public interface Proj4Part2Tests extends ProjTests  { /* category marker */ }